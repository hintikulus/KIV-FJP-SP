package compilator.enums;

public enum EVariableDeclaration {
    DECIMAL,
    METHOD_CALL,
    IDENTIFIER,
    EXPRESSION,
    BOOLEAN
}
