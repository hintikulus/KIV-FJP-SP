package compilator.model.expression;

public interface IExpression {
    public int getOperatorCode();
}
